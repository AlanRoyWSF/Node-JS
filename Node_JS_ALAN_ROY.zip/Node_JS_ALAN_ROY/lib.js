const bar = 10;

exports.myvar = bar;
 