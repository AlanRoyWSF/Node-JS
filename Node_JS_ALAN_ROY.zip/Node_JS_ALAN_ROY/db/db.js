const Sequelize = require("sequelize");
const connection = new Sequelize("mysql://root:@localhost:3306/node-js");

connection
  .authenticate()
  .then(function () {
    console.log("connected");
  })
  .catch(function (err) {
    console.log(err);
  });

module.exports = connection;
