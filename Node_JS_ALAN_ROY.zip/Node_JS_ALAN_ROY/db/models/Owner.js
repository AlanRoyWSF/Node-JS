const { DataTypes, Model } = require("sequelize");
const db = require("../db");

class Owner extends Model {}

// ``
//   firstname: string (max 50char) non null
//   lastname: string (max 100char) non null
//   birthday: date (> 18years old) non null
//   LicenseType: string (doit être voiture ou moto ou bateau ou avion)
// ```


Owner.init(
  {
    firstname : {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    lastname: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    birthday: {
      type: DataTypes.DATE,
      
    },
    LicenseType: {
      type: DataTypes.STRING, 
      
    },
  },
  {
    sequelize: db,
    modelName: "owner",
  }
);

module.exports = Owner;
